<?php

use CodeIgniter\Router\RouteCollection;
use App\Controllers\Accueil;
use App\Controllers\Compte;
use App\Controllers\Actualite;
use App\Controllers\Scenario;
use App\Controllers\Etape;





$routes->get('actualite/afficher', [Actualite::class, 'afficher']);
$routes->get('actualite/afficher/(:num)', [Actualite::class, 'afficher']);



$routes->get('compte/lister', [Compte::class, 'lister']);


$routes->get('accueil/afficher', [Accueil::class, 'afficher']);
$routes->get('accueil/afficher/(:segment)', [Accueil::class, 'afficher']);

$routes->get('accueil/afficher', [Accueil::class, 'afficher']);


$routes->get('/', 'Accueil::index');


$routes->get('scenario/lister', [Scenarios::class, 'lister']);
$routes->get('compte/afficher_org', [Compte::class, 'afficher_org']);
$routes->match(['get', 'post'], 'compte/updatepassword', 'Compte::updatepassword');



$routes->get('etape/afficher/(:segment)', 'Etape::afficher/$1');


$routes->get('scenario/afficher', 'Scenario::afficher');
$routes->get('scenario/afficher_etape/(:alphanum)/(:num)', 'Scenario::afficher_etape/$1/$2');
//$routes->get('scenario/galerie/(:segment)/(:segment)', [Scenario::class, 'afficher_etape']);

$routes->get('compte/creer', [Compte::class, 'creer']); 
$routes->post('compte/creer', [Compte::class, 'creer']); 




$routes->get('compte/connecter', [Compte::class, 'connecter']); 
$routes->post('compte/connecter', [Compte::class, 'connecter']);


$routes->get('compte/deconnecter', [Compte::class, 'deconnecter']); 
$routes->get('compte/afficher_profil', [Compte::class, 'afficher_profil']);


$routes->get('compte/voirscenario/(:segment)', [Compte::class, 'voirscenario']);





// Dans Config/Routes.php

$routes->get('scenario/franchir_etape/(:segment)/(:num)', 'Scenario::franchir_etape/$1/$2');
$routes->post('scenario/franchir_etape/(:segment)/(:num)', 'Scenario::franchir_etape/$1/$2');

$routes->get('scenario/franchir_etape/(:segment)', 'Scenario::franchir_etape/$1');
$routes->post('scenario/franchir_etape/(:segment)', 'Scenario::franchir_etape/$1');

$routes->get('scenario/franchir_etape', 'Scenario::franchir_etape');
$routes->post('scenario/franchir_etape', 'Scenario::franchir_etape');


$routes->get('/scenario/finaliser_jeu/(:segment)/(:segment)', 'Scenario::finaliser_jeu/$1/$2');
$routes->post('/scenario/finaliser_jeu/(:segment)/(:segment)', 'Scenario::finaliser_jeu/$1/$2');
$routes->get('/scenario/succes', 'Scenario::succes');



// In app/Config/Routes.php

$routes->get('compte/creerScenario', [Compte::class, 'creerScenario']); 
$routes->post('compte/creerScenario', [Compte::class, 'creerScenario']);
//$routes->get('compte/delete/(:segment)', [Compte::class, 'delete/$1']);
$routes->get('compte/delete/(:segment)', 'Compte::delete/$1');
$routes->post('compte/delete/(:segment)', 'Compte::delete/$1');

$routes->get('scenario/success', function() {
    return view('templates/haut3')
         . view('connexion/scenario_success')
         . view('templates/bas3');
});


/**
 * @var RouteCollection $routes
 */
//$routes->get('/', 'Home::index');
$routes->get('/', 'Accueil::afficher');
