<?php
/*====================================================================
// Nom du Fchier : Compte.php
//Auteur : Ait charki Aymane
//Date de Creation : 08/11/2023
//version: V1
//++++++++++++++++++++++++++++++++++++++++++++++++
//Description
//Ce Controllr gere l'affichage des comptes  .
//
//----------------------------------------//
// A noter:
//=============================================================*/

namespace App\Controllers;
use App\Models\Db_model;
use CodeIgniter\Exceptions\PageNotFoundException;
class Compte extends BaseController
{
    public function __construct()
    {
    helper('form');
    $this->model = model(Db_model::class);
    }
    public function lister()
    {
        $session = session();
    
        if ($session->has('user')) {
            $model = model(Db_model::class);
            $data['titre'] = "Liste de tous les comptes";
            $data['logins'] = $model->get_all_compte();
            $data['totalComptes'] = $model->count_all_comptes();
    
            return view('templates/haut2', $data)
                . view('affichage_comptes')
                . view('templates/bas2');
        } else {
            return view('templates/haut', ['titre' => 'Se connecter'])
                . view('connexion/compte_connecter')
                . view('templates/bas'); 
        }
    }

    public function creer()
    {
        helper('form'); 
        $model = model(Db_model::class);
        $session = session();
        if ($session->has('user') && $session->get('role') === 'A') {
        // L’utilisateur a validé le formulaire en cliquant sur le bouton
        if ($this->request->getMethod() == "post")
        {
            if (! $this->validate([
                'pseudo' => 'required|max_length[255]|min_length[2]',
                'mdp' => 'required|max_length[255]|min_length[8]',
                'confirm_mdp' => 'required|matches[mdp]',
                'role' => 'required',
                'etat' => 'required', 
            ],
            [ // Configuration des messages d’erreurs
                'pseudo' => [
                    'required' => 'Veuillez entrer un pseudo pour le compte !',
                    'min_length' => 'Le pseudo saisi est trop court !',
                    'max_length' => 'Le pseudo saisi est trop long !',
                ],
                'mdp' => [
                    'required' => 'Veuillez entrer un mot de passe !',
                    'min_length' => 'Le mot de passe saisi est trop court !',
                    'max_length' => 'Le mot de passe saisi est trop long !',
                ],
                'confirm_mdp' => [
                    'required' => 'Veuillez confirmer votre mot de passe !',
                    'matches' => 'La confirmation du mot de passe ne correspond pas au mot de passe saisi !',
                ],
                'role' => [
                    'required' => 'Veuillez sélectionner un rôle pour le compte !',
                ],
                'etat' => [
                    'required' => 'Veuillez sélectionner un état pour le compte !',
                ],
            ])) 
            {
                // La validation du formulaire a échoué, retour au formulaire !
                return view('templates/haut', ['titre' => 'Créer un compte'])
                    . view('compte/compte_creer')
                    . view('templates/bas');
            }
    
            // La validation du formulaire a réussi, traitement du formulaire
            $recuperation = $this->validator->getValidated();
            $resultat = $model->set_compte($recuperation);
    
            if (isset($resultat['error'])) {
                // Afficher un message d'erreur si le compte existe déjà
                return redirect()->back()->with('error', $resultat['error']);
            } else {
                // Procéder normalement si le compte est créé
                $data['le_compte'] = $recuperation['cpt_logincompte'];
                $data['le_message'] = "Nouveau nombre de comptes : ";
                $data['le_total'] = $model->get_nb_comptes();
                return view('templates/haut', $data)
                    . view('compte/compte_succes')
                    . view('templates/bas');
            }
        }
    
        // L’utilisateur veut afficher le formulaire pour créer un compte
        return view('templates/haut', ['titre' => 'Créer un compte'])
            . view('compte/compte_creer')
            . view('templates/bas');


        } else {
            // Redirection vers la page de connexion ou afficher un message d'erreur
            return redirect()->to('/compte/connecter'); // ou une autre page appropriée
        }
    }
    




 public function accueil()
{

   $session = session();
    $model = model(Db_model::class);
    $data['actualites'] = $model->get_all_actualites();
    // Autres données à transmettre...
    return view('templates/haut', $data)
        . view('accueil')
        . view('templates/bas');
}





public function connecter() {
   $model = model(Db_model::class);

   if ($this->request->getMethod() == "post") {
       if (!$this->validate(['pseudo' => 'required', 'mdp' => 'required'])) {
           // La validation du formulaire a échoué, retour au formulaire !
           return view('templates/haut', ['titre' => 'Se connecter'])
               . view('connexion/compte_connecter')
               . view('templates/bas');
       }

       $username = $this->request->getVar('pseudo');
       $password = $this->request->getVar('mdp');

       // Hash du mot de passe entré pour la correspondance
       $hashedPassword = hash('sha256', 'azerty' . $password);
 

      // Vérification des identifiants
      $user = $model->connect_compte($username, $hashedPassword);

       if ($user !== false) {
           if ($user['cpt_rolecompte'] == 'A') {
               $session = session();
               $session->set('user', $username);
               $session->set('role', $user['cpt_rolecompte']);
               return view('templates/haut2')
                   . view('connexion/compte_accueil')
                   . view('templates/bas2');
           } elseif ($user['cpt_rolecompte'] =='O') {
               $session = session();
               $session->set('user', $username);
               $session->set('user_id', $user['cpt_idcompte']);

               return view('templates/haut3')
                   . view('connexion/accueil_organisateur')
                   . view('templates/bas3');
           }
       } else {
           // Identifiants incorrects
           return view('templates/haut', ['titre' => 'Se connecter'])
               . view('connexion/compte_connecter')
               . view('templates/bas');
       }
   }

   // Afficher le formulaire de connexion
   return view('templates/haut', ['titre' => 'Se connecter'])
       . view('connexion/compte_connecter')
       . view('templates/bas');
}






public function afficher_profil()
{
$session=session();
if ($session->has('user'))
{ 
   $model = model('App\Models\Db_model'); 
   $pseudo = $session->get('user');


   
$data['le_message']="Affichage des données du profil ici !!!";
// A COMPLETER...
$data['compte'] = $model->get_compte($pseudo);
return view('templates/haut2',$data)
. view('connexion/compte_profil',$data)
. view('templates/bas2');
}
else
{
return view('templates/haut', ['titre' => 'Se connecter'])
. view('connexion/compte_connecter')
. view('templates/bas'); 
}
}

public function afficher_org()
{
    $session = session(); 

    // Vérifier si l'utilisateur est connecté
    if ($session->has('user')) { 
        $model = model(Db_model::class);
        $login = $session->get('user'); // Récupérer le login de l'utilisateur connecté
        $data['titre'] = "Mes Scénarios";
        $data['scenario'] = $model->get_scenario_org($login); 

        if (empty($data['scenario'])) {
            $data['aucunScenario'] = true; 
        }
        return view('templates/haut3', $data)
               . view('connexion/afficher_scenario')
               . view('templates/bas3');
    }
    else {
        // Rediriger vers la page de connexion si l'utilisateur n'est pas connecté
        return view('templates/haut', ['titre' => 'Se connecter'])
               . view('connexion/compte_connecter')
               . view('templates/bas'); 
    }
}


public function updatepassword()
{
    helper('form');
    $model = model(Db_model::class);

    $session = session();
    if ($session->has('user')) {
        $pseudo = $session->get('user');
        $data['compte'] = $model->get_compte($pseudo);
        $data['le_message'] = "Mes informations personnelles : ";

        if ($this->request->getMethod() == "post") {
            $validationRules = [
                'mdp' => 'required|max_length[255]|min_length[8]',
                'confirm_mdp' => 'required|matches[mdp]',
            ];

            $validationMessages = [
                'mdp' => [
                    'required' => 'Veuillez entrer un mot de passe !',
                    'min_length' => 'Le mot de passe saisi est trop court !',
                    'max_length' => 'Le mot de passe saisi est trop long !',
                ],
                'confirm_mdp' => [
                    'required' => 'Veuillez confirmer votre mot de passe !',
                    'matches' => 'La confirmation du mot de passe ne correspond pas au mot de passe saisi !',
                ],
            ];

            if (!$this->validate($validationRules, $validationMessages)) {
                $errors = $this->validator->getErrors();
                // Modification échouée, afficher les erreurs et rediriger vers la page update_mdp
                if ($data['compte']->cpt_rolecompte === 'A') {
                    return view('templates/haut2', $data)
                        . view('connexion/modifier_mdp', ['validationErrors' => $errors])
                        . view('templates/bas2');
                } elseif ($data['compte']->cpt_rolecompte === 'O') {
                    return view('templates/haut3', $data)
                        . view('connexion/modifier_mdp', ['validationErrors' => $errors])
                        . view('templates/bas3');
                }
            } else {
                // Modification réussie, mettre à jour le mot de passe
                $recuperation = $this->validator->getValidated();
                $model->updat_mdpp($recuperation, $pseudo);

                // Afficher un message de succès
                echo "Votre mot de passe vient d'être modifié.";

                // Rediriger vers la page du profil
                if ($data['compte']->cpt_rolecompte === 'A') {
                    return view('templates/haut2', $data)
                        . view('connexion/compte_profil')
                        . view('templates/bas2');
                } elseif ($data['compte']->cpt_rolecompte === 'O') {
                    return view('templates/haut3', $data)
                        . view('connexion/compte_profil')
                        . view('templates/bas3');
                }
            }
        } else {
            // Afficher la page update_mdp sans traitement de formulaire
            if ($data['compte']->cpt_rolecompte === 'A') {
                return view('templates/haut2', $data)
                    . view('connexion/modifier_mdp')
                    . view('templates/bas2');
            } elseif ($data['compte']->cpt_rolecompte === 'O') {
                return view('templates/haut3', $data)
                    . view('connexion/modifier_mdp')
                    . view('templates/bas3');
            }
        }
    }
}








 public function deconnecter()
 {
 $session=session();
 $session->destroy();
 return view('templates/haut', ['titre' => 'Se connecter'])
 . view('connexion/compte_connecter')
 . view('templates/bas');
 }













 public function voirscenario($scenario_id)
 {
     $session = session();
 
     if (!$session->has('user')) {
         return redirect()->to('/compte/connecter'); // Rediriger vers la page de connexion si l'utilisateur n'est pas connecté
     }
 
     $model = model(Db_model::class);
 
     // Récupérer les détails du scénario spécifié
     $scenario_etapes = $model->get_infos($scenario_id);
 
     
 
     $data['titre'] = "Détails du scénario";
     $data['scenario_etapes'] = $scenario_etapes;

     // Vérifier si des étapes sont présentes
    if (empty($scenario_etapes['nb_etapes']) || $scenario_etapes['nb_etapes'] == 0) {
        $data['aucuneEtape'] = true; 
    }
 
     return view('templates/haut2', $data)
         . view('connexion/details', $data) 
         . view('templates/bas2');
 }
 

public function copierScenario($scenario_id)
{
    $session = session();

    if (!$session->has('user')) {
        return redirect()->to('/compte/connecter'); 
    }

    $model = model(Db_model::class);

    
    $scenario = $model->get_scenario_by_id($scenario_id);

    if (!$scenario) {
        throw new PageNotFoundException("Scénario non trouvé");
    }

    
    $nouveauScenarioId = $model->copier_scenario($scenario_id, $session->get('user'));

    if (!$nouveauScenarioId) {

    }

   
    return redirect()->to('/compte/scenarios');
}


    public function creerScenario()
    {
        $model = model(Db_model::class);
        helper('form');
        $session = session();
        $idcompte = $session->get('user');
        $userid = $model->connect_compte2($idcompte)->cpt_idcompte;


        if (!$session->has('user')) {
            return redirect()->to(base_url('compte/connecter'));
        } elseif ($this->request->getMethod() == "post") {
            $validationRules = [
                'intitule' => 'required|min_length[2]|max_length[255]',
                'etat' => 'required|in_list[A,D]', 
                'image' => 'uploaded[image]|is_image[image]|mime_in[image,image/jpg,image/jpeg,image/gif,image/png,image/webp]',
            ];

            if (!$this->validate($validationRules)) {
                return view('templates/haut3', ['titre' => 'Créer un scénario'])
                    . view('scenario_form', ['validation' => $this->validator])
                    . view('templates/bas3');
            }

            $intitule = $this->request->getVar('intitule');
            $etat = $this->request->getVar('etat');
            $image = $this->request->getFile('image');
            //$idcompte = $session->get('user_id');

            if ($image->isValid() && !$image->hasMoved()) {
                $nomImage = $image->getRandomName();
                $image->move(ROOTPATH . 'public/uploades', $nomImage);
            }

            $this->model->set_scenario($intitule, $etat, $nomImage, $userid);

            return redirect()->to(base_url('index.php/compte/afficher_org'));
        }

        return view('templates/haut3', ['titre' => 'Créer un scénario'])
            . view('scenario_form')
            . view('templates/bas3');
    }
   
    public function delete($idscenario)
    {
        $model = new Db_model();
        $session = session();
    
        if (!$session->has('user')) {
            return redirect()->to(base_url('index.php/compte/connecter'));
        } else {
            $model->deleteScenario($idscenario);
            $data['titre'] = "Liste de tous les Scenarios Existants A/D :";
            $scenario_etapes = $model->get_infos($idscenario);
            $data['titre'] = "Liste de tous les Scenarios";
            $data['scenario'] = $model->get_scenario_org();
            //$data['scenario'] = $scenario_etapes; // Utilisez $idscenario au lieu de sce_codescenario
    
            return view('templates/haut3', $data)
                . view('connexion/afficher_scenario') 
                . view('templates/bas3');
        }
    }







public function afficher_prmiere_etape($code_scenario) {
    $model = new Db_model();
    $session = session();

    if (!$session->has('user')) {
        return redirect()->to(base_url('index.php/compte/connecter'));
    } else {
    $data['etape'] = $this->model->get_etape1($code_scenario); 
   
    return view('templates/haut2', $data)
    .view('afficher_prmiere_etape', $data) 
    . view('templates/bas2');
  
}
}public function franchir_etape($code_etape = null) {
    $model = new Db_model();
    $session = session();

    if (!$session->has('user')) {
        return redirect()->to(base_url('index.php/compte/connecter'));
    }

    if ($code_etape === null) {
        return redirect()->to(base_url('index.php'));
    }

    $etape = $model->get_etape($code_etape);

    if ($this->request->getMethod() == "post") {
        $reponseUtilisateur = $this->request->getPost('reponse');
        $bonneReponse = $model->get_bonne_reponse($code_etape);

        if (strtolower($reponseUtilisateur) == strtolower($bonneReponse)) {
            if ($model->est_derniere_etape($code_etape)) {
                return redirect()->to('/compte/finaliser_jeu');
            } else {
                $code_etape_suivante = $model->get_code_etape_suivante($code_etape);
                return redirect()->to('/compte/franchir_etape/' . $code_etape_suivante);
            }
        } else {
            $data['erreur'] = 'Réponse incorrecte. Veuillez réessayer.';
        }
    }

   
    $data['etape'] = $this->model->get_etape1($code_etape);

    return view('templates/haut', $data)
    .view('afficher_prmiere_etape', $data)
           . view('templates/bas');
}








}

