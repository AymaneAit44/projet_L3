<?php

/*====================================================================
// Nom du Fchier : Etape.php
//Auteur : Ait charki Aymane
//Date de Creation : 08/11/2023
//version: V1
//++++++++++++++++++++++++++++++++++++++++++++++++
//Description
//Ce controller gere l'affichage des etapes  .
//
//----------------------------------------//
// A noter:
//=============================================================*/

namespace App\Controllers;

use App\Models\Db_model;
use CodeIgniter\Exceptions\PageNotFoundException;
use Exception; 

class Etape extends BaseController
{
    public function afficher($numero = 0)
    {
        try {
            $model = model(Db_model::class);

            if ($numero == 0) {
                throw new Exception("Veuillez entrer le numéro du scénario");
            } else {
                $data['etape'] = $model->get_etape($numero);
                return view('templates/haut', $data)
                    . view('affichage_premiere_etape')
                    . view('templates/bas');
            }
        } catch (Exception $e) {
            echo "Erreur : " . $e->getMessage();
        }
    }
}
