<?php
/*====================================================================
// Nom du Fchier : Scenario.php
//Auteur : Ait charki Aymane
//Date de Creation : 08/11/2023
//version: V1
//++++++++++++++++++++++++++++++++++++++++++++++++
//Description
//Ce controller gere l'affichage des scenarios  .
//
//----------------------------------------//
// A noter:
//=============================================================*/

namespace App\Controllers;

use App\Models\Db_model;

class Scenario extends BaseController
{
    public function lister()
    {
        $model = model(Db_model::class);

        $data['titre'] = "Liste des Scénarios";
        $data['scenarios'] = $model->get_scenarios_actives();

        return view('templates/haut', $data)
            . view('affichage_scenarios')
            . view('templates/bas');
    }


    public function afficher()
    {
        $model = model(Db_model::class);
        $data['titre']="Liste de tous les Scenarios";
        $data['scenario']= $model->get_all_scenario();
        
        return view('templates/haut', $data)
        . view('galerie')
        . view('templates/bas');
    }

    public function afficher_etape($numero, $ind)
    {
        $model = model(Db_model::class);
    
        $etape = $model->get_etape1($numero, $ind);
    
        // Vérifier si l'étape est trouvée et si l'indice est valide
        if ($etape != null && $ind >= 1 && $ind <= 3) { 
            $data['ind'] = $ind;
            $data['etape'] = $etape;
        } else {
            // Gérer l'erreur si l'étape n'est pas trouvée ou si l'indice est invalide
            $data['ind'] = $ind;
            $data['etape'] = null;
            $data['erreur'] = "Code de scénario ou indice invalide. Veuillez vérifier et réessayer.";
        }
    
        return view('templates/haut', $data)
            . view('affichage_premiere_etape', $data)
            . view('templates/bas');
    }
    
    public function franchir_etape($code_etape = null, $niveauInd = 0) {
        $model = new Db_model();

        if ($this->request->getMethod() == "post") {
            $reponseUtilisateur = $this->request->getPost('reponse');
            $bonneReponse = $model->get_bonne_reponse($code_etape);

            if (strtolower($reponseUtilisateur) == strtolower($bonneReponse)) {
                $prochaineEtape = $model->get_prochaine_etape($code_etape);

                if ($prochaineEtape) {
                    return redirect()->to('/scenario/franchir_etape/' . $prochaineEtape . '/' . $niveauInd);
                } else {
                    // Obtenez le code du scénario avant de rediriger
                    $code_scenario = $model->getCodeScenarioParEtape($code_etape);
                    return redirect()->to('/scenario/finaliser_jeu/' . $code_scenario . '/' . $niveauInd);
                }
            } else {
                $data['erreur'] = 'Réponse incorrecte. Veuillez réessayer.';
            }
        }

        $data['etape'] = $model->get_etape($code_etape, $niveauInd);
        $data['ind'] = $niveauInd;
        return view('templates/haut', $data)
            . view('etape_form', $data)
            . view('templates/bas');
    }
    public function finaliser_jeu($code_etape = null, $niveau_difficulte = null) {
        $model = new Db_model();
        
        
       
            $code_scenario = $model->getCodeScenarioParEtape($code_etape);
     
    
        if (!$model->scenarioExiste($code_scenario)) {
            return view('erreur', ['message' => "L'information recherchée n'existe pas !"]);
        }
    
        if ($this->request->getMethod() == "post") {
            $identifiantUtilisateur = $this->request->getPost('identifiant');
            $model->enregistrerReussite($identifiantUtilisateur, $code_scenario, $niveau_difficulte);
            return redirect()->to('/scenario/succes');
        }
    
        return view('templates/haut')
            . view('finaliser_jeu', ['code_scenario' => $code_scenario, 'niveau_difficulte' => $niveau_difficulte])
            . view('templates/bas');
    }
    
    

    
}
