<?php
/*====================================================================
// Nom du Fchier : Db_model.php V1
//Auteur : Ait charki Aymane
//Date de Creation : 08/11/2023
//version: V1
//++++++++++++++++++++++++++++++++++++++++++++++++
//Description
//Ce Model gere la connexion, recupération, la mosdification et le persistance dans la base de donnée  .
//
//----------------------------------------//
// A noter:
//=============================================================*/
	namespace App\Models;
	use CodeIgniter\Model;
	class Db_model extends Model


	{
	 protected $db;
	 public function __construct()
	 {
	 $this->db = db_connect(); //charger la base de données
	 // ou 
	 // $this->db = \Config\Database::connect();
	 }

	 /* Fonction membre à ajouter sous le constructeur et get_all_compte() : */
	 public function get_actualite($numero)
	 {
		
	 $requete="SELECT * FROM T_actualite_act WHERE act_etatactualite='A';";
	 $resultat = $this->db->query($requete);
	 return $resultat->getResultArray();
	 }
	 
	public function get_all_compte()
		{
		$resultat = $this->db->query("SELECT * FROM T_compte_cpt;");
		return $resultat->getResultArray();
		}

	//fonction membre qui compte le nombre total de comptes utilisateur dans la table des comptes.

	public function count_all_comptes()
		{
			$result = $this->db->query("SELECT COUNT(*) as total FROM T_compte_cpt;");
			return $result->getRow()->total;
		}

	//Récupère toutes les actualités en joignant les tables T_actualite_act et T_compte_cpt.

		public function get_all_actualites()
		{
			$resultat = $this->db->query("SELECT * FROM T_actualite_act
			JOIN T_compte_cpt USING(cpt_idcompte) where act_etatactualite='A';");  
			return $resultat->getResultArray();
		}



		public function get_scenario_org(){
			$resultat = $this->db->query("SELECT 
			
			sce.sce_intitulescenario, 
			sce.sce_codescenario, 
			cpt.cpt_logincompte, 
			sce.sce_etatscenario, 
			sce.sce_image, 
			COUNT(etp.etp_idetape) AS nb_etapes
		FROM T_scenario_sce sce
		JOIN T_compte_cpt cpt ON sce.cpt_idcompte = cpt.cpt_idcompte
		LEFT JOIN T_etape_etp etp ON sce.sce_idscenario = etp.sce_idscenario
		GROUP BY sce.sce_idscenario;");
			return $resultat->getResultArray();
		}



		public function get_nb_etape(){
			$resultat = $this->db->query("SELECT count(sce_idscenario) FROM T_etape_etp
			where sce_idscenario=1");
			return $resultat->getResultArray();
		}








		public function get_scenario_by_id($scenarioId)
	{
		$query = $this->db->table('T_scenario_sce')
			->select('sce_intitulescenario, sce_codescenario, cpt_logincompte')
			->join('T_compte_cpt', 'T_scenario_sce.cpt_idcompte = T_compte_cpt.cpt_idcompte')
			->where('sce_etatscenario', 'A')
			->where('sce_codescenario', $scenarioId)
			->groupBy('sce_intitulescenario');

		return $query->get()->getResultArray();
	}

	public function get_etapes_by_scenario($scenario_id)
	{
		return $this->db->table('T_etape_etp')
			->where('sce_codescenario', $scenario_id)
			->get()
			->getResultArray();
	}





		
		
	   

	//Récupère tous les scénarios distincts qui sont actifs (sce_etatscenario='A'),
		public function get_all_scenario(){
			$resultat = $this->db->query("SELECT DISTINCT * FROM T_scenario_sce
		JOIN T_compte_cpt USING(cpt_idcompte)
		LEFT join T_etape_etp using(sce_idscenario)
		LEFT join T_Indice_ind using(etp_idetape)
		where sce_etatscenario='A'
		group by sce_intitulescenario");
			return $resultat->getResultArray();
		}

	//Récupère tous les scénarios actifs (sce_etatscenario = 'A')
		public function get_scenarios_actives()
	{
		$requete = "SELECT *
		FROM T_scenario_sce
		JOIN T_compte_cpt USING(cpt_idcompte)
		
		
		
		WHERE sce_etatscenario = 'A';";
		$resultat = $this->db->query($requete);
		return $resultat->getResultArray();
	}






	// Récupère la première étape d'un scénario spécifique (identifié par $numero) et un niveau d'indice spécifique ($ind), 


	public function get_etape1($numero,$ind)
		{
			$resultat = $this->db->query("SELECT * FROM T_etape_etp
			JOIN T_scenario_sce USING(sce_idscenario)
			LEFT JOIN T_Indice_ind ON T_etape_etp.etp_idetape = T_Indice_ind.etp_idetape AND T_Indice_ind.ind_niveaundice = '" . $ind . "'
			WHERE sce_codescenario LIKE '" . $numero . "' AND etp_ordreetape = 1;");
			return $resultat->getRow();

	}
	//Compte le nombre total de comptes utilisateurs,

	public function get_nb_comptes()
	 {
	 // Fonction créée et testée dans le précédent tutoriel
	 $resultat=$this->db->query("SELECT COUNT(*) as nb FROM T_compte_cpt;");
	 return $resultat->getRow();
	 }


	 public function compteExiste($login) {
		$query = $this->db->table('T_compte_cpt')
						  ->where('cpt_logincompte', $login)
						  ->countAllResults();
		return $query > 0;
	}



	 public function set_compte($saisie)
	 {
	 //Récuparation (+ traitement si nécessaire) des données du formulaire
	 $login=$saisie['pseudo'];
	 if ($this->compteExiste($login)) {
		return ['error' => 'Compte déjà existant'];
	}
	 $mot_de_passe=$saisie['mdp'];
	 $etat = $saisie['etat'];  
	 $role = $saisie['role'];
	 $sql="INSERT INTO T_compte_cpt (cpt_idcompte,cpt_activecompte, cpt_rolecompte, cpt_logincompte, cpt_mdpcompte)  VALUES(NULL,'".$etat."','".$role."','".$login."','".$mot_de_passe."');";
	 return $this->db->query($sql);
	 }





	public function set_scenario($intitule, $etat, $image, $idcompte)
		{
			
			$code = $this->generateScenarioCode();

			$sql = "INSERT INTO T_scenario_sce (sce_intitulescenario, sce_etatscenario, sce_codescenario, sce_image, cpt_idcompte) 
					VALUES (?, ?, ?, ?, ?)";
			
			return $this->db->query($sql, [$intitule, $etat, $code, $image, $idcompte]);
		}

		private function generateScenarioCode()
		{
			
			$characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
			$code = '';
			for ($i = 0; $i < 8; $i++) {
				$code .= $characters[rand(0, strlen($characters) - 1)];
			}
			return $code;
		}


		public function deleteScenario($code)
		{
		
	$requete1 = "DELETE FROM T_scenario_participant_sp WHERE sce_idscenario IN (SELECT sce_idscenario FROM T_scenario_sce WHERE sce_codescenario = '".$code."');";
	$requete0 = "DELETE FROM T_Indice_ind WHERE etp_idetape IN (SELECT etp_idetape FROM T_etape_etp JOIN T_scenario_sce ON T_etape_etp.sce_idscenario = T_scenario_sce.sce_idscenario WHERE sce_codescenario = '".$code."');";

	$requete = "DELETE FROM T_etape_etp WHERE sce_idscenario IN (SELECT sce_idscenario FROM T_scenario_sce WHERE sce_codescenario = '".$code."');";
	$requete2 = "DELETE FROM T_scenario_sce WHERE sce_codescenario = '".$code."';";


	$query1 = $this->db->query($requete1);
	$query0 = $this->db->query($requete0);
	$query = $this->db->query($requete);
	$query2 = $this->db->query($requete2);

	// Retourne vrai si toutes les requêtes ont été exécutées avec succès
	return ($query1 && $query0 && $query && $query2);
		
		}
		
		
		
	 public function connect_compte2($u)
	 {
		 $sql = "SELECT cpt_logincompte,  cpt_idcompte
				 FROM T_compte_cpt
				 WHERE cpt_logincompte = '".$u."';";
			  
		 $resultat = $this->db->query($sql);
	 
		 if ($resultat->getNumRows() > 0) {
			 return $resultat->getRow(); // Renvoie les informations de l'utilisateur
		 } else {
			 return false;
		 }

		}


	 
	 


	 public function connect_compte($u, $p)
	 {
		 $sql = "SELECT cpt_logincompte, cpt_mdpcompte, cpt_rolecompte , cpt_idcompte
				 FROM T_compte_cpt
				 WHERE cpt_logincompte = '".$u."'
				 AND cpt_mdpcompte = '".$p."';";
		 $resultat = $this->db->query($sql);
	 
		 if ($resultat->getNumRows() > 0) {
			 return $resultat->getRowArray(); // Renvoie les informations de l'utilisateur
		 } else {
			 return false;
		 }
	 }






	 
	 public function updat_mdpp($saisie,$pseudo)
	 {
		 $password=$saisie['mdp'];
	 
		 $sql1 = "UPDATE T_compte_cpt
				 SET cpt_mdpcompte = '" . $password . "'
				 WHERE cpt_logincompte = '" . $pseudo . "'";
	 
		 return $this->db->query($sql1);
			 
	 }



	 public function get_infos($numero)
	 {
		 $resultat = $this->db->query("SELECT * FROM T_scenario_sce
									   LEFT JOIN T_etape_etp ON T_scenario_sce.sce_idscenario = T_etape_etp.sce_idscenario
									   WHERE sce_codescenario LIKE '" . $numero . "' ;");
		 return $resultat->getResult();
	 }
	 



	   /*---------------------------------------------------------------------------------
										partie administration
			--------------------------------------------------------------------------------*/ 
			/*-------------------------------------------------------------
			fonction mombres qui modifier le mot de passe  .
			--------------------------------------------------------------*/
			public function update_password($password){
				
				$this->db->where('cpt_pseudo' , $this->session->userdata('username'));
				return  $this->db->update('T_compte_cpt', array('cpt_mdpcompte' => $password));
			   }
			   /*--------------------------------------------------
				fonction mombres qui récupere tous les donnés d'un compte .
				---------------------------------------------------*/
				public function get_all_about_profil()
				{
					$query = $this->db->query("SELECT * FROM T_compte_cpt ");
					return $query->getResultArray();
				}
				
				/*--------------------------------------------------
				fonction mombres qui récupere les donnés d'un compte connecté .
				---------------------------------------------------*/
				public function get_compte($pseudo){
					$session = session();
					$requete1 = $this->db->query("SELECT * FROM T_compte_cpt WHERE cpt_logincompte = ?", [$pseudo]);
					return $requete1->getRow();
				}




				public function est_derniere_etape($code_etape) {
					// Requête pour vérifier si l'étape est la dernière dans le scénario
					$requete = "SELECT 
									(etp_ordreetape = (SELECT MAX(etp_ordreetape) FROM T_etape_etp WHERE sce_idscenario = e.sce_idscenario)) AS est_derniere_etape
								FROM 
									T_etape_etp AS e
								WHERE 
									e.etp_idetape = ?";
				
					$resultat = $this->db->query($requete, [$code_etape]);
				
					if ($resultat->getNumRows() > 0) {
						$ligne = $resultat->getRowArray();
						return $ligne['est_derniere_etape'] == 1;
					}
				
					// Retourner faux si l'étape n'est pas trouvée
					return false;
				}
				public function get_code_etape_suivante($code_etape) {
					// Obtenir les détails de l'étape actuelle
					$etapeActuelle = $this->get_etape($code_etape);
					if (!$etapeActuelle) {
						return null; // Retourne null si l'étape actuelle n'est pas trouvée
					}
				
					// Trouver l'étape suivante
					$query = $this->db->table('T_etape_etp')
						->where('sce_idscenario', $etapeActuelle['sce_idscenario'])
						->where('etp_ordreetape', $etapeActuelle['etp_ordreetape'] + 1)
						->get();
				
					if ($query->getNumRows() > 0) {
						return $query->getRow()->etp_codeetape;
					}
				
					return null; // Retourne null si aucune étape suivante n'est trouvée
				}
				





				public function get_bonne_reponse($code_etape)
	{
		$requete = "SELECT etp_reponseetape FROM T_etape_etp WHERE etp_codeetape = ?";
		$resultat = $this->db->query($requete, [$code_etape]);
		$ligne = $resultat->getRow();

		return $ligne ? $ligne->etp_reponseetape : null;
	}



	public function get_prochaine_etape($code_etape_actuelle)
	{
		// Tout d'abord, obtenez l'ordre et le scénario de l'étape actuelle
		$requeteActuelle = "SELECT * FROM T_etape_etp WHERE etp_codeetape = ?";
		$resultatActuel = $this->db->query($requeteActuelle, [$code_etape_actuelle]);
		$etapeActuelle = $resultatActuel->getRow();

		if (!$etapeActuelle) {
			return null;
		}

		// Ensuite, trouvez la prochaine étape dans le même scénario
		$requeteSuivante = "SELECT * FROM T_etape_etp WHERE sce_idscenario = ? AND etp_ordreetape = ?";
		$resultatSuivant = $this->db->query($requeteSuivante, [$etapeActuelle->sce_idscenario, $etapeActuelle->etp_ordreetape + 1]);

		$etapeSuivante = $resultatSuivant->getRow();
		return $etapeSuivante ? $etapeSuivante->etp_codeetape : null;
	}


	public function get_etape($code_etape)
	{
		// Spécifier les champs à récupérer
		$requete = "SELECT etp.etp_codeetape, etp.etp_intituleetape, etp.etp_questionetape, etp.etp_reponseetape, 
					ind.ind_descriptionindice, ind.ind_lienindice
					FROM T_etape_etp etp
					LEFT JOIN T_Indice_ind ind ON etp.etp_idetape = ind.etp_idetape
					WHERE etp.etp_codeetape = ?";

		// Exécuter la requête avec le code de l'étape
		$resultat = $this->db->query($requete, [$code_etape]);

		// Vérifier si des résultats sont retournés
		if ($resultat->getNumRows() > 0) {
			// Retourner la première ligne des résultats
			return $resultat->getRowArray();
		} else {
			// Retourner null si aucun résultat n'est trouvé
			return null;
		}
	}
	public function scenarioExiste($code_scenario) {
		$requete = "SELECT COUNT(*) as nombre FROM T_scenario_sce 
					WHERE sce_codescenario = ?";
		$resultat = $this->db->query($requete, [$code_scenario]);
		$ligne = $resultat->getRow();

		return $ligne->nombre > 0;
	}

	public function enregistrerReussite($utilisateur, $code_scenario, $niveau_difficulte) {
		$date_actuelle = date("Y-m-d H:i:s");

		$queryScenario = "SELECT sce_idscenario FROM T_scenario_sce WHERE sce_codescenario = ?";
		$resultScenario = $this->db->query($queryScenario, [$code_scenario]);
		$scenarioRow = $resultScenario->getRow();

		if ($scenarioRow) {
			$scenarioId = $scenarioRow->sce_idscenario;

			$requete = "INSERT INTO T_scenario_participant_sp (sce_idscenario, par_adresseparticipant, sp_date_premier_reussite, sp_date_dernier_reussite, sp_niveau_reussite) 
						VALUES (?, ?, ?, ?, ?)";
			
			$resultat = $this->db->query($requete, [$scenarioId, $utilisateur, $date_actuelle, $date_actuelle, $niveau_difficulte]);

			return $resultat;
		} else {
			return false;
		
		}
	}
	public function getCodeScenarioParEtape($code_etape) {
		$query = $this->db->query("SELECT sce_codescenario FROM T_etape_etp WHERE etp_codeetape = ?", [$code_etape]);
		$result = $query->getRowArray();
		return $result ? $result['sce_codescenario'] : null;
	}


				
				
	}




    


