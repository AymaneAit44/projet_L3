Contenu de la page d'accueil !!
<h1>
<?php
//echo $parametre_url;
?>
</h1>