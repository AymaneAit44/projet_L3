<h1><?php echo $titre;?></h1><br />




<?php if (isset($news)): ?>
    <div>
        <strong>ID de l'actualité:</strong> <?php echo $news->act_idactualite; ?>
    </div>
    <div>
        <strong>Description / Intitulé:</strong> <?php echo $news->act_descintitule; ?>
    </div>
    <!-- Ajoutez d'autres détails d'actualité si nécessaire -->

<?php else: ?>
    <p>Pas d'actualité .</p>
<?php endif; ?>