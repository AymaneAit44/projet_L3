<!-- affichage_actualites.php -->
<h2>Liste des Actualités</h2>
<?php if (!empty($actualites) && is_array($actualites)) : ?>
    <table style="border-collapse: collapse; width: 100%;">
        <thead>
            <tr style="border: 1px solid #dddddd; text-align: left; padding: 8px;">
            <th style="border: 1px solid #dddddd; padding: 8px;">Nom</th>
                <th style="border: 1px solid #dddddd; padding: 8px;">Intitule</th>
                <th style="border: 1px solid #dddddd; padding: 8px;">Description</th>
               
                <th style="border: 1px solid #dddddd; padding: 8px;">Date</th>
                <!-- Ajoutez d'autres colonnes au besoin -->
            </tr>
        </thead>
        <tbody>
            <?php foreach ($actualites as $actualite) : ?>
                <tr style="border: 1px solid #dddddd; text-align: left; padding: 8px;">
                <td style="border: 1px solid #dddddd; padding: 8px;"><?php echo $actualite['cpt_logincompte']; ?></td>
                    <td style="border: 1px solid #dddddd; padding: 8px;"><?php echo $actualite['act_intituleactualite']; ?></td>
                    <td style="border: 1px solid #dddddd; padding: 8px;"><?php echo $actualite['act_descintitule']; ?></td>
                    
                    <td style="border: 1px solid #dddddd; padding: 8px;"><?php echo $actualite['act_dateactualite']; ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php else : ?>
    <p>Aucune actualité</p>
<?php endif; ?>
