<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Liste des comptes</title>
    <div class="center-content">
    <a href="https://obiwan.univ-brest.fr/~e22010244/index.php/compte/creer">
        <button type="submit" class="btn btn-primary mb-2">Ajouter un nouveau compte</button>
    </a>
</div>



    <style>
        .center-content {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 20vh; 
}

        body {
            font-family: Arial, sans-serif;
        }
        .container {
            width: 80%;
            margin: 0 auto;
        }
        h2 {
            text-align: center;
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            text-align: left;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
            padding: 10px;
        }
        td {
            padding: 10px;
        }
        .btn-activer {
            background-color: #4CAF50;
            color: white;
            padding: 10px;
            text-decoration: none;
            border: none;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2><?php echo $titre; ?></h2>
        <p>Total des comptes : <?php echo $totalComptes; ?></p>

        <?php if (!empty($logins) && is_array($logins)) { ?>
            <table>
                <tr>
                    <th>Nom</th>
                    <th>Prenom</th>
                    <th>Role</th>
                    <th>Validite</th>
                    <th>Login</th>
                    <th>Action</th>
                </tr>
                <?php foreach ($logins as $pseudos) { ?>
                    <tr>
                        <td><?php echo $pseudos["cpt_nom"]; ?></td>
                        <td><?php echo $pseudos["cpt_prenom"]; ?></td>
                        <td><?php echo $pseudos["cpt_rolecompte"]; ?></td>
                        <td><?php echo $pseudos["cpt_activecompte"]; ?></td>
                        <td><?php echo $pseudos["cpt_logincompte"]; ?></td>
                        <td><button class="btn-activer">Activer</button></td>
                    </tr>
                <?php } ?>
            </table>
        <?php } else { ?>
            <h3>Aucun compte pour le moment</h3>
        <?php } ?>
    </div>
</body>
</html>
