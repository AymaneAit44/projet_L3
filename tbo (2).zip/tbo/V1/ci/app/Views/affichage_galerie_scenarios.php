<h1>Galerie des Scénarios Disponibles :</h1>

<?php foreach ($scenarios as $scenario): ?>
    <div>
        <!-- Remplacez 'nom' et 'auteur' par les noms des attributs appropriés de votre base de données -->
        <h2><?= esc($scenario->sce_intitulescenario); ?></h2>
        <p>Auteur: <?= esc($scenario->cpt_logincompte); ?></p>
        <p>
            <!-- Assurez-vous que 'sce_codescenario' est le nom de l'attribut pour le code du scénario dans votre base de données -->
            <a href="<?= site_url('scenario/afficher_etapes/' . $scenario->sce_codescenario . '/1'); ?>">Niveau de Difficulté : Facile</a><br>
            <a href="<?= site_url('scenario/afficher_etapes/' . $scenario->sce_codescenario . '/2'); ?>">Niveau de Difficulté : Moyen</a><br>
            <a href="<?= site_url('scenario/afficher_etapes/' . $scenario->sce_codescenario . '/3'); ?>">Niveau de Difficulté : Difficile</a>
        </p>
    </div>
<?php endforeach; ?>
