<?php if (isset($etape) && $etape != null) : ?>
    <div style="max-width: 700px; margin: 0 auto;">
        <form action="<?= site_url('scenario/franchir_etape/' . $etape->etp_codeetape.'/'.$ind); ?>" method="post">
            <div style="border: 3px solid #ccc; padding: 4px; margin-bottom: 4px; text-align: center;">
                <h5 style="text-align: center;"><?= htmlspecialchars($etape->etp_intituleetape); ?></h5>
                <h5 style="text-align: center;"><?= htmlspecialchars($etape->etp_questionetape); ?></h5>

                <div class="form-group">
                    <label for="reponse">Réponse :</label>
                    <input type="text" class="form-control" id="reponse" name="reponse" placeholder="Saisissez votre réponse">
                </div>
                <button type="submit" class="btn btn-primary">Soumettre</button>
                <?php if (isset($etape->ind_lienindice)): ?>
                    <a href="<?= htmlspecialchars($etape->ind_lienindice); ?>" target="_blank">
                        <img src="<?= base_url().'/uploades/icon1.jpeg'; ?>" alt="Indice" style="max-width: 30px;">
                    </a>
                <?php endif; ?>
            </div>
        </form>
        <h6>Ressources</h6>
        <?php if (isset($etape->rsc_cheminressources)): ?>
            <p>
                <a href="<?= htmlspecialchars($etape->rsc_cheminressources); ?>" target="_blank">
                    <?= htmlspecialchars($etape->rsc_cheminressources); ?>
                </a>
            </p>
        <?php endif; ?>
    </div>
<?php else : ?>
    <p>Il y a eu une erreur. Soit le code de scénario, l'indice, ou les deux sont manquants ou incorrects. Veuillez vérifier et réessayer.</p>
<?php endif; ?>
