<h2><?php echo $titre; ?></h2>
<?php if (!empty($scenarios) && is_array($scenarios)) : ?>
    <div>
        <?php foreach ($scenarios as $scenario) : ?>
            <div>
                <h3><?php echo $scenario['sce_intitulescenario']; ?></h3>
                <img src="<?php echo base_url().'/bootstrap/assets/img/image_base/'.$scenario['sce_image']; ?>" alt="Logo du scénario">

                <p>Auteur : <?php echo $scenario['cpt_logincompte']; ?></p>
                <p>Niveau de difficulté : <?php echo $scenario['sp_niveau_reussite']; ?></p>
            </div>
        <?php endforeach; ?>
    </div>
<?php else : ?>
    <p>Aucun scénario disponible pour le moment.</p>
<?php endif; ?>
