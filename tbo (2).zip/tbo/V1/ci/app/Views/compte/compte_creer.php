<!DOCTYPE html>
<html>
<head>
    <title>Création de Compte</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
            padding: 20px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
        }
        input[type='input'], input[type='password'], select {
            width: 100%;
            padding: 8px;
            margin: 5px 0 20px 0;
            display: inline-block;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        input[type='submit'] {
            width: 100%;
            background-color: #4CAF50;
            color: white;
            padding: 14px 20px;
            margin: 8px 0;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        input[type='submit']:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <h2><?= $titre; ?></h2>

    <?= session()->getFlashdata('error') ?>

    <?= form_open('/compte/creer'); ?>
    <?= csrf_field() ?>

    <div class="form-group">
        <label for="pseudo">Pseudo :</label>
        <input type="input" name="pseudo">
        <?= validation_show_error('pseudo') ?>
    </div>

    <div class="form-group">
        <label for="mdp">Mot de passe :</label>
        <input type="password" name="mdp">
        <?= validation_show_error('mdp') ?>
    </div>

    <div class="form-group">
        <label for="confirm_mdp">Confirmer le mot de passe :</label>
        <input type="password" name="confirm_mdp">
        <?= validation_show_error('confirm_mdp') ?>
    </div>

    <div class="form-group">
        <label for="role">Rôle :</label>
        <select name="role">
            <option value="A">Administrateur</option>
            <option value="O">Organisateur</option>
        </select>
    </div>

    <div class="form-group">
        <label for="etat">État :</label>
        <select name="etat">
            <option value="A">Activée</option>
            <option value="D">Désactivé</option>
        </select>
    </div>

    <input type="submit" name="submit" value="Créer un nouveau compte">
    </form>
</body>
</html>
