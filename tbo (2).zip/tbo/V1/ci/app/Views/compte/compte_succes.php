Bravo ! Formulaire rempli, le compte suivant a été ajouté :
<?php
echo $le_compte;
echo $le_message;
echo $le_total->nb;
?>