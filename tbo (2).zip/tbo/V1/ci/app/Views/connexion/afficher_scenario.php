<div class="container">
    <h2><?php echo $titre; ?></h2>
    <?php if (isset($aucunScenario) && $aucunScenario): ?>
        <p>Aucun scénario disponible pour le moment.</p>
    <?php else: ?>
        <table class="table hoverable">
            <thead>
                <tr>
                    <th>Intitulé du Scénario</th>
                    <th>Code du Scénario</th>
                    <th>Auteur</th>
                    <th>Nombre d'étapes</th>
                    <th>États</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($scenario as $sce) : ?>
                    <tr>
                        <td>
                            <?php echo htmlspecialchars($sce['sce_intitulescenario']); ?>
                            <img src="<?php echo base_url().'/uploades/'.$sce['sce_image']; ?>" style="width: 100px; height: auto;">
                        </td>
                        <td><?php echo htmlspecialchars($sce['sce_codescenario']); ?></td>
                        <td><?php echo htmlspecialchars($sce['cpt_logincompte']); ?></td>
                        <td><?php echo htmlspecialchars($sce['nb_etapes']); ?></td>
                        <td><?php echo htmlspecialchars($sce['sce_etatscenario']); ?></td>
                        <td>
                            <!-- Lien pour la visualisation -->
                            <a href="<?php echo base_url('index.php/compte/voirscenario/'.$sce['sce_codescenario']); ?>" title="Visualiser"><i class="fa fa-eye"></i></a>

                            <?php if ($sce['cpt_logincompte'] == session()->get('user')): ?>
                                <!-- Lien pour la modification -->
                                <a href="<?php echo base_url('organisateur/modifier_scenario/'.$sce['sce_codescenario']); ?>" title="Modifier"><i class="fa fa-edit"></i></a>

                                <!-- Lien pour supprimer -->
                                <a href="<?php echo base_url('index.php/compte/delete/'.$sce['sce_codescenario']); ?>" title="Supprimer"><i class="fa fa-trash"></i></a>
                            <?php endif; ?>

                            <!-- Icônes accessibles à tous les utilisateurs -->
                            <button class="btn btn-secondary copy-btn" data-clipboard-text="<?php echo $sce['sce_codescenario']; ?>"><i class="fas fa-copy"></i></button>
                            <a href="<?php echo base_url('organisateur/activer_scenario/'.$sce['sce_codescenario']); ?>" title="Activer/Désactiver"><i class="fa fa-toggle-on"></i></a>
                            <a href="<?php echo base_url('organisateur/copier_scenario/'.$sce['sce_codescenario']); ?>" title="Copier"><i class="fa fa-copy"></i></a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <div style="text-align: center; margin-top: 20px;">
            <a href="https://obiwan.univ-brest.fr/~e22010244/index.php/compte/creerScenario">
                <i class="fas fa-cog" style="font-size: 24px;"></i>
                <p>Ajouter un scénario</p>
            </a>
        </div>
    <?php endif; ?>
</div>

<style>
    .table.hoverable tbody tr:hover {
        background-color: #FFE2A6;
    }
    .action-icon {
        margin-right: 10px;
        color: #333;
        cursor: pointer;
    }
    .action-icon:hover {
        color: #007bff;
        transform: scale(1.1);
    }
</style>
