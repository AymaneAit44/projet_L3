<!DOCTYPE html>
<html>
<head>
    <title><?= $titre; ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
            padding: 20px;
        }
        .form-container {
            background: white;
            max-width: 400px;
            margin: 20px auto;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
        }
        input[type='input'], input[type='password'] {
            width: 100%;
            padding: 8px;
            margin: 5px 0 20px 0;
            display: inline-block;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        input[type='submit'] {
            width: 100%;
            background-color: #4CAF50;
            color: white;
            padding: 14px 20px;
            margin: 8px 0;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        input[type='submit']:hover {
            background-color: #45a049;
        }
        .error {
            color: red;
            font-size: 0.9em;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2><?= $titre; ?></h2>
        <?php if (session()->getFlashdata('error')): ?>
            <p class="error"><?= session()->getFlashdata('error') ?></p>
        <?php endif; ?>
        
        <?= form_open('/compte/connecter'); ?>
        <?= csrf_field() ?>

        <div class="form-group">
            <label for="pseudo">Pseudo :</label>
            <input type="input" name="pseudo" value="<?= set_value('pseudo') ?>">
            <?= validation_show_error('pseudo') ?>
        </div>

        <div class="form-group">
            <label for="mdp">Mot de passe :</label>
            <input type="password" name="mdp">
            <?= validation_show_error('mdp') ?>
        </div>

        <input type="submit" name="submit" value="Se connecter">
        </form>
    </div>
</body>
</html>
