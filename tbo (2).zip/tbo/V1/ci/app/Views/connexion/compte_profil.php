<!DOCTYPE html>
<html>
<head>
    <style>
        .admin-info {
            text-align: center;
            color: grey;
            font-weight: bold;
        }
    </style>
</head>


</body>
</html>



<!DOCTYPE html>
<html>
<head>
    <title>Espace d'Administration</title>
    <style>




        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
            padding: 20px;
        }
        .admin-container {
            background: white;
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .admin-header {
            background-color: #FFCC00;
            color: white;
            text-align: center;
            padding: 10px 0;
            border-top-left-radius: 8px;
            border-top-right-radius: 8px;
        }
        .admin-body {
            padding: 20px;
        }
        .admin-label {
            font-weight: bold;
            display: block;
        }
        .admin-info {
            color: #333;
            font-size: 1.1em;
            margin-bottom: 15px;
        }
        .row {
            display: flex;
            justify-content: space-between;
        }
        .col-md-6 {
            flex: 0 0 48%;
            max-width: 48%;
        }
    </style>
</head>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Informations personnelles</title>
    <style>
        .zebra-table {
            width: 100%;
            border-collapse: collapse;
        }

        .zebra-table tr:nth-child(even) {
            background-color: #f2f2f2
;
        }

        .zebra-table td {
            padding: 8px;
            text-align: left;
        }

        .admin-label {
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <div class="admin-header">
            <h2>Informations personnelles</h2>
        </div>
        <div class="admin-body">
            <?php
            $session = session();
            ?>
            <table class="zebra-table">
                <tr>
                    <td><span class='admin-label'>Utilisateur :</span></td>
                    <td><span class='admin-info'><?php echo $session->get('user'); ?></span></td>
                </tr>
                <?php if (!empty($compte) && is_object($compte)) { ?>
                    <tr>
                        <td><span class="admin-label">Pseudo:</span></td>
                        <td><span class="admin-info"><?php echo $compte->cpt_logincompte; ?></span></td>
                    </tr>
                    <tr>
                        <td><span class="admin-label">Nom:</span></td>
                        <td><span class="admin-info"><?php echo $compte->cpt_nom; ?></span></td>
                    </tr>
                    <tr>
                        <td><span class="admin-label">Prenom:</span></td>
                        <td><span class="admin-info"><?php echo $compte->cpt_prenom; ?></span></td>
                    </tr>
                <?php } ?>
            </table>
            <div style="text-align: center; margin-top: 20px;">
                <a href="https://obiwan.univ-brest.fr/~e22010244/index.php/compte/updatepassword">
                    <i class="fas fa-cog" style="font-size:24px;"></i>
                    <p>Paramètre</p>
                </a>
            </div>
        </div>
    </div>
</body>
</html>
