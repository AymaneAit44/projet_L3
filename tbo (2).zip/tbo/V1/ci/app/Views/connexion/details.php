<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Votre Titre</title>
    <style>
        /* Styles pour le tableau */
        .container {
            margin: 20px;
        }

        h2 {
            font-size: 24px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 8px 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #f2f2f2;
        }

        /* Styles pour les boutons */
        .action-buttons a {
            display: inline-block;
            padding: 5px 10px;
            margin-right: 5px;
            text-decoration: none;
            background-color: #007bff;
            color: #fff;
            border-radius: 3px;
        }

        .action-buttons a:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
<div class="container">
    <h2><?php echo $titre; ?></h2>
    <?php if (!empty($scenario_etapes)) : ?>
        <table class="table hoverable">
            <thead>
                <tr>
                    <th>Intitulé du Scénario</th>
                    <th>Code du Scénario</th>
                    <th>Auteur</th>
                    <!-- Ajoutez des en-têtes pour les étapes -->
                    <th>Étape</th>
                    <th>Question</th>
                    <th>Réponse</th>
                   <!--   <th>Actions</th>-->
                </tr>
            </thead>
            <tbody>
                <?php foreach ($scenario_etapes as $item) : ?>
                    <tr>
                        <td><?php echo htmlspecialchars($item->sce_intitulescenario); ?></td>
                        <td><?php echo htmlspecialchars($item->sce_codescenario); ?></td>
                        <td><?php echo htmlspecialchars($item->cpt_logincompte); ?></td>
                        <td><?php echo htmlspecialchars($item->etp_intituleetape); ?></td>
                        <td><?php echo htmlspecialchars($item->etp_questionetape); ?></td>
                        <td><?php echo htmlspecialchars($item->etp_reponseetape); ?></td>
                     <!-- <td class="action-buttons">
                            <a href="modifier_scenario.php?id=<?php echo $item->id; ?>">Modifier</a>
                            <a href="supprimer_scenario.php?id=<?php echo $item->id; ?>">Supprimer</a>
                        </td>-->
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else : ?>
        <p>Aucun étape disponible pour le moment.</p>
    <?php endif; ?>
</div>
</body>
</html>
