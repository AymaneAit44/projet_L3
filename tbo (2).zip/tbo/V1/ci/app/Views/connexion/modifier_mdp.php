<style>
    .form-container {
        width: 100%;
        max-width: 400px;
        margin: 20px auto;
        padding: 20px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        background-color: #f9f9f9;
    }

    .form-container label {
        display: block;
        margin-bottom: 5px;
        font-weight: bold;
    }

    .form-container input[type="text"],
    .form-container input[type="password"] {
        width: 100%;
        padding: 8px;
        margin-bottom: 20px;
        border: 1px solid #ddd;
        border-radius: 4px;
    }

    .form-container button,
    .form-container .btn {
        width: 100%;
        padding: 10px;
        margin-bottom: 10px;
        border: none;
        border-radius: 4px;
        color: white;
        cursor: pointer;
    }

    .form-container button {
        background-color: #007bff;
    }

    .form-container button:hover {
        background-color: #0056b3;
    }

    .form-container .btn {
        background-color: #6c757d;
        text-decoration: none;
        display: inline-block;
        text-align: center;
    }

    .form-container .btn:hover {
        background-color: #545b62;
    }

    .error-messages {
        color: red;
        margin-bottom: 15px;
    }
</style>



<div class="form-container">
<form action="<?= site_url('compte/updatepassword') ?>" method="post">

        <!-- Nom -->
        <label for="nom">Nom :</label>
        <input type="text" name="nom" id="nom" value="<?= $compte->cpt_nom ?>" readonly>

        <!-- Prénom -->
        <label for="prenom">Prénom :</label>
        <input type="text" name="prenom" id="prenom" value="<?= $compte->cpt_prenom ?>" readonly>

        <!-- Mot de passe -->
        <label for="mdp">Nouveau mot de passe :</label>
        <input type="password" name="mdp" id="mdp" placeholder="Nouveau mot de passe">

        <!-- Confirmation du mot de passe -->
        <label for="confirm_mdp">Confirmation du mot de passe :</label>
        <input type="password" name="confirm_mdp" id="confirm_mdp" placeholder="Confirmez le mot de passe">

        <!-- Messages d'erreur pour la validation -->
        <?php if (isset($validation)) : ?>
            <div class="error-messages">
                <?= $validation->listErrors() ?>
            </div>
        <?php endif; ?>

        <!-- Boutons -->
        <a href="https://obiwan.univ-brest.fr/~e22010244/index.php/compte/updatepassword">
    <button type="submit">Valider</button>
</a>

        <a href="https://obiwan.univ-brest.fr/~e22010244/index.php/compte/afficher_profil" class="btn">Annuler</a>
    </form>
</div>
