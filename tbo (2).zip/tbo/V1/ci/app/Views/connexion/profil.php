<!-- Supposons que cette vue soit enregistrée sous le nom 'profile.php' dans le dossier 'connexion' -->
<div class="container">
    <h2>Profil</h2>
    <?php if (session()->has('success')): ?>
        <div class="alert alert-success">
            <?= session('success') ?>
        </div>
    <?php endif; ?>
    <p>Bienvenue, <?= $user->cpt_logincompte ?>!</p>
    <p>Nom : <?= $user->cpt_nom ?></p>
    <p>Prénom : <?= $user->cpt_prenom ?></p>
    <!-- Ajoutez plus de détails du profil si nécessaire -->
    <a href="<?= site_url('compte/editProfile') ?>" class="btn btn-primary">Éditer le profil</a>
    <a href="<?= site_url('compte/changePassword') ?>" class="btn btn-warning">Changer le mot de passe</a>
</div>
