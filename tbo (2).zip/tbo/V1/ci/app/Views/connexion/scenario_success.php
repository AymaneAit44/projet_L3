<!-- File: app/Views/connexion/scenario_success.php -->

<h2>Scénario Créé avec Succès</h2>

<p>Le scénario a été créé avec succès.</p>

<a href="<?= site_url('https://obiwan.univ-brest.fr/~e22010244/index.php/compte/afficher_org'); ?>" class="btn btn-primary">Retour à la liste des scénarios</a>
