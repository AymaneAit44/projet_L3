<div class="container">
    <h2><?php echo $titre; ?></h2>
    <?php if (!empty($scenario_etapes)) : ?>
        <table class="table hoverable">
            <thead>
                <tr>
                    <th>Intitulé du Scénario</th>
                    <th>Code du Scénario</th>
                    <th>Auteur</th>
                    <!-- Ajoutez des en-têtes pour les étapes -->
                    <th>Étape</th>
                    <th>Question</th>
                    <th>Réponse</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($scenario_etapes as $item) : ?>
                    <tr>
                        <td><?php echo htmlspecialchars($item->sce_intitulescenario); ?></td>
                        <td><?php echo htmlspecialchars($item->sce_codescenario); ?></td>
                        <td><?php echo htmlspecialchars($item->cpt_logincompte); ?></td>
                        <td><?php echo htmlspecialchars($item->etp_intituleetape); ?></td>
                        <td><?php echo htmlspecialchars($item->etp_questionetape); ?></td>
                        <td><?php echo htmlspecialchars($item->etp_reponseetape); ?></td>
                        <td>
                            <!-- Les actions que vous avez déjà -->
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else : ?>
        <p>Aucun scénario disponible pour le moment.</p>
    <?php endif; ?>
</div>

<!-- Votre style existant ici -->
