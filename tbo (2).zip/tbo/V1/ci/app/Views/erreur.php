<!-- Dans app/Views/erreur.php -->

<h1>Erreur</h1>
<p><?= esc($message) ?></p>
