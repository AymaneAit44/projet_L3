<!-- erreur_scenario.php -->
<div class="container">
    <h2>Erreur</h2>
    <p><?php echo isset($erreur) ? $erreur : 'Une erreur inattendue est survenue.'; ?></p>
</div>
