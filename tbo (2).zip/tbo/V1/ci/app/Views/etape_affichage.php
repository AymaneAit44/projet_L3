<!-- Dans Views/etape_affichage.php -->

<?php if (isset($step)) : ?>
    <h1><?= $step->etp_intituleetape ?></h1>
    <p><?= $step->etp_questionetape ?></p>

    <?php if (isset($erreur) && $erreur != ''): ?>
        <p style="color: red;"><?= $erreur ?></p>
    <?php endif; ?>

    <form action="<?= site_url('scenario/franchir_etape/' . $lecode); ?>" method="post">
        <input type="text" name="reponse" placeholder="Saisissez votre réponse">
        <button type="submit">Soumettre</button>
    </form>
    <!-- Hyperlien pour l'indice en fonction du niveau de difficulté -->
    <!-- ... -->
<?php else: ?>
    <p>Aucune étape trouvée pour ce code.</p>
<?php endif; ?>
