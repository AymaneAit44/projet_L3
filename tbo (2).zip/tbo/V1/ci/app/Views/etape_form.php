<!-- Dans Views/etape_form.php -->

<?php if (isset($etape) && $etape != null) : ?>
    <div style="max-width: 700px; margin: 0 auto;">
        <form action="<?= site_url('scenario/franchir_etape/' . $etape['etp_codeetape'] . '/' . $ind); ?>" method="post">
            <h5><?= esc($etape['etp_intituleetape']); ?></h5>
            <p><?= esc($etape['etp_questionetape']); ?></p>
            <input type="text" name="reponse" placeholder="Saisissez votre réponse">
            <button type="submit">Soumettre</button>
        </form>
        <?php if (isset($erreur)): ?>
            <p style="color: red;"><?= esc($erreur); ?></p>
        <?php endif; ?>
    </div>
<?php else : ?>
    <p>Étape non trouvée ou indice incorrect. Veuillez réessayer.</p>
<?php endif; ?>
