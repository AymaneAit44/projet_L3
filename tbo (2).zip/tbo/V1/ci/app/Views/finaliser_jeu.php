<h1>Félicitations pour avoir terminé le scénario !</h1>
<form action="<?= site_url('scenario/finaliser_jeu/' . $code_scenario . '/' . $niveau_difficulte); ?>" method="post">
    <input type="text" name="identifiant" placeholder="Votre identifiant" required>
    <button type="submit">Enregistrer ma réussite</button>
</form>
