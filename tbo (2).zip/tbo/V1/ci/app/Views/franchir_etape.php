<!-- Dans /Views/franchir_etape.php -->

<h1>Étape actuelle : <?= $etape['titre'] ?></h1>
<p><?= $etape['description'] ?></p>

<!-- Afficher d'autres détails de l'étape si nécessaire -->

<!-- Formulaire pour passer à l'étape suivante -->
<form action="<?= base_url('compte/franchir_etape') ?>" method="post">
    <input type="hidden" name="code_etape" value="<?= $etape['code_etape_suivante'] ?>">
    <input type="submit" value="Passer à l'étape suivante">
</form>
