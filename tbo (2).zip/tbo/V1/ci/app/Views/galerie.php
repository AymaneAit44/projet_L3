<h3 style="text-align: center;"><?php echo $titre; ?></h3>

<?php if (!empty($scenario) && is_array($scenario)) : ?>
     <div style="max-width: 700px; margin: 0 auto;">
        <?php foreach ($scenario as $scenarios) : ?>
            <div style="border: 3px solid #ccc; padding: 4px; margin-bottom: 4px ; text-align: center;">
                <h3 style="text-align: center;"><?php echo $scenarios['sce_intitulescenario']; ?></h3>
                <div>
                    <img src="<?php echo base_url().'/uploades/'.$scenarios['sce_image']; ?>" alt="Illustration du scénario">
                </div>
                <h6>Auteur Nom :</h6><p><?php echo $scenarios['cpt_logincompte']; ?></p>
                
                
                
                <button>
                    <a href="https://obiwan.univ-brest.fr/~e22010244/index.php/scenario/afficher_etape/<?php echo $scenarios['sce_codescenario']; ?>/1">Niveau: 1</a>
                </button>

                <button>
                    <a href="https://obiwan.univ-brest.fr/~e22010244/index.php/scenario/afficher_etape/<?php echo $scenarios['sce_codescenario']; ?>/2">Niveau: 2</a>
                </button>

                <button>
                    <a href="https://obiwan.univ-brest.fr/~e22010244/index.php/scenario/afficher_etape/<?php echo $scenarios['sce_codescenario']; ?>/3">Niveau: 3</a>
                </button>
                
            </div>
        <?php endforeach; ?>
    </div>
<?php else : ?>
    <p>Aucun scénario disponible pour le moment.</p>
<?php endif; ?>