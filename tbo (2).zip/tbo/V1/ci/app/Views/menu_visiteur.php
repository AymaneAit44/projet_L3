<!-- menu_visiteur.php -->
<nav>
    <ul>
        <li><a href="<?php echo base_url(); ?>">Accueil</a></li>
        <li><a href="<?php echo base_url('compte/lister'); ?>">Liste des comptes</a></li>
        <!-- Ajoutez d'autres liens de menu si nécessaire -->
    </ul>
</nav>
