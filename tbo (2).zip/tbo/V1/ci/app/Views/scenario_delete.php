<!-- Vue scenario_delete.php -->
<!DOCTYPE html>
<html>
<head>
    <title>Suppression de scénario</title>
</head>
<body>
    <h1>Suppression de scénario</h1>
    <p><?= $message ?></p>
    <a href="<?= base_url('index.php/compte/afficher_org') ?>">Retour à la liste des scénarios</a>
</body>
</html>

