<!-- Assuming this file is located at app/Views/connexion/scenario_form.php -->

<h2><?= esc($titre) ?></h2>

<?php if (isset($validation)): ?>
    <div class="alert alert-danger">
        <?= $validation->listErrors() ?>
    </div>
<?php endif; ?>

<form action="<?= site_url('compte/creerScenario'); ?>" method="post" enctype="multipart/form-data">
    <?= csrf_field() ?>

    <div class="form-group">
        <label for="intitule">Intitulé du Scénario:</label>
        <input type="text" name="intitule" id="intitule" class="form-control" value="<?= old('intitule') ?>" required>
    </div>

    <div class="form-group">
        <label for="etat">État du Scénario:</label>
        <input type="text" name="etat" id="etat" class="form-control" value="<?= old('etat') ?>" required>
    </div>

    <div class="form-group">
        <label for="image">Image (max 1MB):</label>
        <input type="file" name="image" id="image" class="form-control" required>
    </div>

    <button type="submit" class="btn btn-primary">Créer</button>
</form>
