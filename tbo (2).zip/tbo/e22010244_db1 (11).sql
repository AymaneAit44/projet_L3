-- phpMyAdmin SQL Dump
-- version 5.0.4deb2+deb11u1
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:3306
-- Généré le : ven. 15 déc. 2023 à 12:53
-- Version du serveur :  10.5.19-MariaDB-0+deb11u2
-- Version de PHP : 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `e22010244_db1`
--

DELIMITER $$
--
-- Procédures
--
CREATE DEFINER=`e22010244sql`@`%` PROCEDURE `delete_scenario` (IN `sce_id` INT)  BEGIN
    DELETE FROM T_scenario_participant_sp WHERE sce_idscenario = sce_id;
    DELETE FROM T_etape_etp WHERE sce_idscenario = sce_id;
    DELETE FROM T_scenario_sce WHERE sce_idscenario = sce_id;
END$$

CREATE DEFINER=`e22010244sql`@`%` PROCEDURE `InfoScenario` (IN `p_id_scenario` INT, OUT `p_info_scenario` VARCHAR(500))  BEGIN
  DECLARE scenario_title VARCHAR(45);
  DECLARE participant_count INT;
  DECLARE first_participant VARCHAR(45);
  DECLARE first_participation_date VARCHAR(45);

  SELECT sce_intitulescenario INTO scenario_title
  FROM T_Scenarion_sce
  WHERE sce_idscenario = p_id_scenario;

  SELECT COUNT(*) INTO participant_count
  FROM T_Scenarion_participant_sp
  WHERE sce_idscenario = p_id_scenario;

  SELECT par_adresseparticipant, sp_date_premier_reussite INTO first_participant, first_participation_date
  FROM T_Scenarion_participant_sp
  WHERE sce_idscenario = p_id_scenario
  ORDER BY sp_date_premier_reussite ASC
  LIMIT 1;

  SET p_info_scenario = CONCAT('Intitulé du scénario : ', scenario_title, '; Nombre de participants : ', participant_count, '; Premier participant : ', first_participant, '; Date de première participation : ', first_participation_date);
END$$

CREATE DEFINER=`e22010244sql`@`%` PROCEDURE `participant_sce` (IN `scenarioId` INT)  BEGIN
    SELECT GROUP_CONCAT(cpt_pseudo SEPARATOR ', ')
    FROM T_compte_cpt
    INNER JOIN T_Scenarion_sce
    ON T_compte_cpt.cpt_idcompte = T_Scenarion_sce.cpt_idcompte
    WHERE T_Scenarion_sce.sce_idscenario = scenarioId;
END$$

CREATE DEFINER=`e22010244sql`@`%` PROCEDURE `RecapParticipantsScenario` (IN `scenarioID` INT)  BEGIN
    DECLARE participantList VARCHAR(500);  -- Définir une variable pour stocker la liste des participants
    SELECT GROUP_CONCAT(par_adresseparticipant) INTO participantList
    FROM T_Scenarion_participant_sp
    WHERE sce_idscenario = scenarioID;
    
    SELECT participantList AS RecapParticipants;  -- Renvoie la liste des participants
END$$

CREATE DEFINER=`e22010244sql`@`%` PROCEDURE `scenario_descriptif` (IN `id_scenario` INT, OUT `texte` TEXT)  BEGIN
    DECLARE intitule_scenario VARCHAR(150);
    DECLARE nb_part INT;
    DECLARE premier_part VARCHAR(150);
    DECLARE premiere_date_part DATE;

    -- Obtenir l'intitulé du scénario
    SELECT sce_intitulescenario INTO intitule_scenario FROM T_scenario_sce WHERE sce_idscenario = id_scenario;

    -- Obtenir le nombre de participants
    SELECT COUNT(*) INTO nb_part FROM T_participant_par WHERE sce_idscenario = id_scenario;

    IF nb_part = 0 THEN
        SET texte = 'Aucun participant';
    ELSE
        -- Obtenir le premier participant et sa première date de réussite
        SELECT par_adresseparticipant, MIN(sp_date_premier_reussite) INTO premier_part, premiere_date_part
        FROM T_participant_par
        JOIN T_scenario_participant_sp USING(par_adresseparticipant)
        WHERE sce_idscenario = id_scenario;

        SET texte = CONCAT(
            'L''intitulé du scénario: ', intitule_scenario,
            ', le nombre des participants est: ', nb_part,
            '. Le premier participant est : ', premier_part,
            '. La date de sa première réussite: ', premiere_date_part
        );
    END IF;
END$$

--
-- Fonctions
--
CREATE DEFINER=`e22010244sql`@`%` FUNCTION `NombreParticipantsScenario` (`p_id_scenario` INT) RETURNS INT(11) BEGIN
  DECLARE participant_count INT;
  SELECT COUNT(*) INTO participant_count
  FROM T_Scenarion_participant_sp
  WHERE sce_idscenario = p_id_scenario;
  RETURN participant_count;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `T_actualite_act`
--

CREATE TABLE `T_actualite_act` (
  `act_idactualite` int(11) NOT NULL,
  `act_intituleactualite` varchar(45) NOT NULL,
  `act_descintitule` varchar(500) NOT NULL,
  `act_etatactualite` char(1) NOT NULL,
  `act_dateactualite` varchar(45) NOT NULL,
  `cpt_idcompte` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `T_actualite_act`
--

INSERT INTO `T_actualite_act` (`act_idactualite`, `act_intituleactualite`, `act_descintitule`, `act_etatactualite`, `act_dateactualite`, `cpt_idcompte`) VALUES
(5, 'FG', 'VBN', 'A', '09-10-2023', 1),
(6, 'FDSQ', 'FDSQ', 'D', '09-10-2023', 22),
(7, '', 'mis à jour', 'A', '24-06-2023', 23),
(8, '', 'mis à jour', 'A', '24-06-2023', 23),
(9, '', 'NOUVELLE ETAPE', 'A', '24-06-2023', 23),
(10, '', 'mis à jour', 'A', '24-06-2023', 23);

-- --------------------------------------------------------

--
-- Structure de la table `T_compte_cpt`
--

CREATE TABLE `T_compte_cpt` (
  `cpt_idcompte` int(11) NOT NULL,
  `cpt_activecompte` varchar(45) NOT NULL,
  `cpt_rolecompte` char(1) NOT NULL,
  `cpt_logincompte` varchar(45) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `cpt_mdpcompte` char(64) NOT NULL,
  `cpt_nom` varchar(20) DEFAULT NULL,
  `cpt_prenom` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `T_compte_cpt`
--

INSERT INTO `T_compte_cpt` (`cpt_idcompte`, `cpt_activecompte`, `cpt_rolecompte`, `cpt_logincompte`, `cpt_mdpcompte`, `cpt_nom`, `cpt_prenom`) VALUES
(1, 'A', 'O', 'krimoo', '2b0da86fcec93db8a9a6b077b7309262b2f9a6610fed6246953e0e75a3533095', NULL, NULL),
(3, 'A', 'O', 'karim', '2db3c8fd9b0f2c9bbb55d054624e9191d18c67367282a4ee515d3443c2488f76', 'karim', 'nari'),
(4, 'A', 'O', 'youssef', '5312f12a54966726410450a6f72430f338be559f4e8ec32745a911ec28c29e74', NULL, NULL),
(5, 'A', 'O', 'zik', '9683bf657aa482df500c7722d6c4ced20361f133ee57cffd347fddd82412724b', NULL, NULL),
(6, 'A', 'A', 'Aymane', '42636abc5b564117d10e6729046f14f0fc7a9d5bcb33accea0022cff1d76ea49', 'Aymane', 'charki'),
(7, 'A', 'A', 'administrATeur', '84bfb425408d802f4a3c6af84c199d01457e429c3ddd6b1566ef24fd59ac7bf8', 'Valerie', 'Marc'),
(10, 'A', 'A', 'KKKK', 'VGBHNJ?KL', NULL, NULL),
(11, 'A', 'A', 'GHJK', 'JHGV', NULL, NULL),
(22, 'A', 'A', 'fghjkl', 'dfghnjk-è', NULL, NULL),
(23, 'A', 'A', 'fghjklggghgg', 'dfghnjk-è', NULL, NULL),
(27, 'A', 'A', 'yayayyazyz', 'hgdhgdhgdgh-é', NULL, NULL),
(29, 'A', 'A', 'soso1', 'f3903b7ae745e9e8a1af1e86d131c563c77277e78cd5f9af459bd1d587e95e6d', NULL, NULL),
(32, 'A', 'A', 'taha', '30f4489530b10178437e7a1f1ec8f6d5f1039526a0f10a8dc84443be91b6f564', NULL, NULL),
(33, 'A', 'A', 'toto', '66399bb997f55dbf4ad77e7ef076142af7607166ddf56fc8fda850518fb1fc1f', NULL, NULL),
(35, 'A', 'A', 'ahmad', '0ff38e30e96664be98ae9e4853146dfd2cfdfb7ecdf7d8a99e1a7c6a579487b5', NULL, NULL),
(36, 'A', 'A', 'yaya', '352b4504b2fa3a4697c84d511cadfa55c46d3e2088fbb308a71f4d458ba3823e', NULL, NULL),
(40, 'A', 'A', 'naroto', 'a073a56fb36fb7453319342606f61676767a6acefe076e68aaf811f0f3070963', NULL, NULL),
(42, 'A', 'A', 'sek', '935f72978be0e8e6b23125c7b733d5e3f55a3fc96c4b69736377baf0617674e1', NULL, NULL),
(44, 'A', 'O', 'noorr', '344bb0f1011493fcd5dcefc92c07d18a0c46f235fabc82d4b7b237909e4dc76f', NULL, NULL),
(46, 'A', 'A', 'acv', '344bb0f1011493fcd5dcefc92c07d18a0c46f235fabc82d4b7b237909e4dc76f', NULL, NULL),
(47, 'A', 'A', 'aqs', '60d826ee6240b8424b7c08c15f007e142a8ab7fcb846977e09db19e7b8de7d3c', NULL, NULL),
(48, 'A', 'O', 'VM22VM', '84bfb425408d802f4a3c6af84c199d01457e429c3ddd6b1566ef24fd59ac7bf8', NULL, NULL);

--
-- Déclencheurs `T_compte_cpt`
--
DELIMITER $$
CREATE TRIGGER `hash_password_before_insert` BEFORE INSERT ON `T_compte_cpt` FOR EACH ROW BEGIN
    SET NEW.cpt_mdpcompte = SHA2(CONCAT('azerty', NEW.cpt_mdpcompte), 256);
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `hash_password_before_update` BEFORE UPDATE ON `T_compte_cpt` FOR EACH ROW BEGIN
    SET NEW.cpt_mdpcompte = SHA2(CONCAT('azerty', NEW.cpt_mdpcompte), 256);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `T_etape_etp`
--

CREATE TABLE `T_etape_etp` (
  `etp_idetape` int(11) NOT NULL,
  `etp_codeetape` char(8) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `etp_descetape` varchar(500) NOT NULL,
  `etp_intituleetape` varchar(45) NOT NULL,
  `etp_questionetape` varchar(500) NOT NULL,
  `etp_reponseetape` varchar(500) NOT NULL,
  `rsc_idressources` int(11) NOT NULL,
  `sce_idscenario` int(11) NOT NULL,
  `etp_ordreetape` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `T_etape_etp`
--

INSERT INTO `T_etape_etp` (`etp_idetape`, `etp_codeetape`, `etp_descetape`, `etp_intituleetape`, `etp_questionetape`, `etp_reponseetape`, `rsc_idressources`, `sce_idscenario`, `etp_ordreetape`) VALUES
(16, 'ZE098390', 'Associer les logos des clubs de football européens à leur nom.', 'Les Clubs de Football Européens', 'c quoi la nationalite de messi', 'Argentine', 2, 2, 1),
(17, 'ZE098393', ' Identifier les villes d origine de différents clubs.', 'Les Clubs de Football Européens', 'De quelle ville est originaire le club de football du Bayern Munich ?', 'Munich', 2, 2, 2),
(18, 'ZE098392', 'Répondre à des questions sur les joueurs légendaires de ces clubs.', 'Les Clubs de Football Européens', 'Qui est le meilleur buteur de tous les temps du FC Barcelone ?', 'Messi', 2, 2, 3),
(19, 'ZE098398', 'Découvrir les surnoms des clubs et leurs significations.', 'Les Clubs de Football Européens', 'Quel est le surnom du club de football du Borussia Dortmund ?', 'Jaune et noire', 2, 2, 4),
(20, 'ZE098395', 'Trouver les années de fondation des clubs.', 'Les Clubs de Football Européens', 'En quelle année a été fondé le club de football de la Juventus ?', '1897', 2, 2, 5),
(21, 'AY1609YU', ' Répondre à des questions sur les règles du football.', 'Les Règles du Jeu', 'Combien de joueurs y a-t-il dans une équipe de football sur le terrain en même temps ?', '11', 2, 3, 1),
(22, 'AY1609YX', '  Identifier les différents types de cartons (jaune, rouge) et leurs significations.', 'Les Règles du Jeu', 'Quel est le carton utilisé pour avertir un joueur avant de lui montrer le carton rouge en cas de faute grave ?', 'carte jaune', 2, 3, 2),
(23, 'AY1609Y0', '  Associer les positions des joueurs sur le terrain à leurs rôles.', 'Les Règles du Jeu', 'Quel est le joueur chargé de défendre les buts de son équipe ?', 'Le gardien', 2, 3, 3),
(24, 'AY1609Y1', '  Répondre à des questions sur les règles du hors-jeu.', 'Les Règles du Jeu', 'Quand est-ce qu un joueur est considéré en position de hors-jeu ?', 'adverse', 2, 3, 4),
(25, 'AY1609YX', '  Découvrir les sanctions pour différentes fautes pendant un match.', 'Les Règles du Jeu', 'Quelle est la sanction pour une faute grave qui empêche une occasion de but ?', 'coup franc', 2, 3, 5),
(26, 'AY1609Y5', 'Les Grands Tournois Européens', 'les pays qui ont remporté l\'Euro ;', 'Quel pays a remporté l\'Euro en 2020 ?', 'L\'Italie.', 2, 4, 1),
(27, 'AY1609Y6', 'Les Grands Tournois Européens', 'les pays qui ont remporté l\'Euro ;', 'Quel pays a remporté l\'Euro en 2020 ?', 'L\'Italie.', 1, 4, 2),
(28, 'AY1609Y7', 'Les Grands Tournois Européens', 'les pays qui ont remporté l\'Euro ;', 'Quel pays a remporté l\'Euro en 2020 ?', 'L\'Italie.', 2, 4, 3),
(29, 'AY1609Y8', 'Les Grands Tournois Européens', 'les pays qui ont remporté l\'Euro ;', 'Quel pays a remporté l\'Euro en 2020 ?', 'L\'Italie.', 1, 4, 4);

-- --------------------------------------------------------

--
-- Structure de la table `T_Indice_ind`
--

CREATE TABLE `T_Indice_ind` (
  `ind_idindice` int(11) NOT NULL,
  `ind_descriptionindice` varchar(500) NOT NULL,
  `ind_lienindice` varchar(300) NOT NULL,
  `ind_niveaundice` varchar(45) NOT NULL,
  `etp_idetape` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `T_Indice_ind`
--

INSERT INTO `T_Indice_ind` (`ind_idindice`, `ind_descriptionindice`, `ind_lienindice`, `ind_niveaundice`, `etp_idetape`) VALUES
(5, 'Image6', 'Doc/usr/indice3', '3', 23),
(6, 'Image7', 'Doc/usr/indice4', '3', 23),
(7, 'Image8', 'Doc/usr/indice6', '3', 23),
(8, 'Image9', 'Doc/usr/indice9', '3', 23);

-- --------------------------------------------------------

--
-- Structure de la table `T_participant_par`
--

CREATE TABLE `T_participant_par` (
  `par_adresseparticipant` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `T_participant_par`
--

INSERT INTO `T_participant_par` (`par_adresseparticipant`) VALUES
('ahmadsefr@gmail.com'),
('ahmadsefr@jugf.com'),
('azert@gmail'),
('cvbn@ghjk.com'),
('nadir@gmail.com'),
('nasr@gmail.com'),
('ysf@gmail.com');

-- --------------------------------------------------------

--
-- Structure de la table `T_ressources_rsc`
--

CREATE TABLE `T_ressources_rsc` (
  `rsc_idressources` int(11) NOT NULL,
  `rsc_cheminressources` varchar(300) NOT NULL,
  `rsc_typesressources` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `T_ressources_rsc`
--

INSERT INTO `T_ressources_rsc` (`rsc_idressources`, `rsc_cheminressources`, `rsc_typesressources`) VALUES
(1, 'image2', 'image'),
(2, 'image3', 'image'),
(3, 'test', 'test');

-- --------------------------------------------------------

--
-- Structure de la table `T_scenario_participant_sp`
--

CREATE TABLE `T_scenario_participant_sp` (
  `sce_idscenario` int(11) NOT NULL,
  `par_adresseparticipant` varchar(500) NOT NULL,
  `sp_date_premier_reussite` datetime NOT NULL,
  `sp_date_dernier_reussite` datetime NOT NULL,
  `sp_niveau_reussite` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `T_scenario_participant_sp`
--

INSERT INTO `T_scenario_participant_sp` (`sce_idscenario`, `par_adresseparticipant`, `sp_date_premier_reussite`, `sp_date_dernier_reussite`, `sp_niveau_reussite`) VALUES
(4, 'ysf@gmail.com', '2023-10-04 14:25:12', '2023-10-13 14:25:12', '1');

-- --------------------------------------------------------

--
-- Structure de la table `T_scenario_sce`
--

CREATE TABLE `T_scenario_sce` (
  `sce_idscenario` int(11) NOT NULL,
  `sce_intitulescenario` varchar(500) DEFAULT NULL,
  `sce_etatscenario` char(2) NOT NULL,
  `sce_codescenario` char(10) NOT NULL,
  `sce_image` varchar(45) NOT NULL,
  `cpt_idcompte` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `T_scenario_sce`
--

INSERT INTO `T_scenario_sce` (`sce_idscenario`, `sce_intitulescenario`, `sce_etatscenario`, `sce_codescenario`, `sce_image`, `cpt_idcompte`) VALUES
(2, 'Les Clubs de Football Européens', 'A', 'AC784374FD', 'image3', 7),
(3, 'Les Règles du Jeu', 'A', 'AC784375FD', 'image4', 6),
(4, 'Les Grands Tournois Européens', 'A', 'AC784376FD', 'image5', 4),
(7, 'ahmad', 'A', 'sefrioui', '20231204/1701705240_515345bd148f7162a993.png', 10),
(9, 'ahmad', 'A', 'sefrioui', '20231204/1701706089_96701cafcde8d8a968ef.png', NULL),
(42, 'mpp', 'Z', '3d96d0a95e', '/home/2023DIFAL3/e22010244/public_html/V1/ci/', NULL),
(43, 'mpp', 'Z', 'ae5d6b71f6', '/home/2023DIFAL3/e22010244/public_html/V1/ci/', NULL),
(44, 'mpp', 'Z', '7b93675756', '1701975447_184dff3fb78c89faea8e.png', NULL),
(45, 'mpp', 'Z', '205a421b84', '1701976027_3fd1b6bb09d3fc478948.png', NULL),
(46, 'pppppppppppp', 'Z', '5a3cc55096', '1701976179_1efbd030ecf1757446f7.png', NULL),
(58, 'AQW', 'Z', 'fb8H5WGR', '1702045922_6328d37c7ce298abdb9a.png', NULL),
(59, 'pml', 'A', 'RLaEB82w', '1702046341_55d77a6032ed569cc148.png', NULL),
(60, 'pml', 'A', 'GJMv0j7A', '1702046682_ad45a5073e2138ff5d25.png', NULL),
(70, 'DFGHè*', 'A', '6TNsGNTX', '1702394562_4ed29d7ce7254dbe727d.png', 3),
(73, 'L\'OR', 'A', 'AHzOdBZJ', '1702476494_e212da2ec3c4368909a8.jpeg', 48);

--
-- Déclencheurs `T_scenario_sce`
--
DELIMITER $$
CREATE TRIGGER `cache_scenario` BEFORE UPDATE ON `T_scenario_sce` FOR EACH ROW BEGIN
    DECLARE id INT;
    DECLARE c TEXT;
    IF NEW.sce_etatscenario = 'CA' THEN
        CALL scenario_descriptif(NEW.sce_idscenario, c);
        SET id = (SELECT cpt_idcompte FROM T_compte_cpt WHERE cpt_logincompte LIKE 'administrATeur'); 

        INSERT INTO T_actualite_act (act_intituleactualite, act_descactualite, act_etatactualite, act_dateactualite, cpt_idcompte)
        VALUES (CONCAT('scénario', NEW.sce_idscenario, 'caché'), c, 'A', CURRENT_DATE, id);

        SET NEW.sce_intitulescenario = CONCAT(OLD.sce_intitulescenario, 'caché le ', CURRENT_DATE);
    END IF;
END
$$
DELIMITER ;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `T_actualite_act`
--
ALTER TABLE `T_actualite_act`
  ADD PRIMARY KEY (`act_idactualite`),
  ADD KEY `fk_T_actualite_act_T_compte_cpt_idx` (`cpt_idcompte`);

--
-- Index pour la table `T_compte_cpt`
--
ALTER TABLE `T_compte_cpt`
  ADD PRIMARY KEY (`cpt_idcompte`),
  ADD UNIQUE KEY `cpt_logincompte_UNIQUE` (`cpt_logincompte`);

--
-- Index pour la table `T_etape_etp`
--
ALTER TABLE `T_etape_etp`
  ADD PRIMARY KEY (`etp_idetape`),
  ADD KEY `fk_T_etape_etp_T_ressources_rsc1_idx` (`rsc_idressources`),
  ADD KEY `fk_T_etape_etp_T_Scenarion_sce1_idx` (`sce_idscenario`);

--
-- Index pour la table `T_Indice_ind`
--
ALTER TABLE `T_Indice_ind`
  ADD PRIMARY KEY (`ind_idindice`),
  ADD KEY `fk_T_Indice_ind_T_etape_etp1_idx` (`etp_idetape`);

--
-- Index pour la table `T_participant_par`
--
ALTER TABLE `T_participant_par`
  ADD PRIMARY KEY (`par_adresseparticipant`),
  ADD UNIQUE KEY `par_adresseparticipant_UNIQUE` (`par_adresseparticipant`);

--
-- Index pour la table `T_ressources_rsc`
--
ALTER TABLE `T_ressources_rsc`
  ADD PRIMARY KEY (`rsc_idressources`);

--
-- Index pour la table `T_scenario_participant_sp`
--
ALTER TABLE `T_scenario_participant_sp`
  ADD PRIMARY KEY (`sce_idscenario`,`par_adresseparticipant`),
  ADD UNIQUE KEY `par_adresseparticipant_UNIQUE` (`par_adresseparticipant`),
  ADD KEY `fk_T_Scenarion_sce_has_T_participant_par_T_participant_par1_idx` (`par_adresseparticipant`),
  ADD KEY `fk_T_Scenarion_sce_has_T_participant_par_T_Scenarion_sce1_idx` (`sce_idscenario`);

--
-- Index pour la table `T_scenario_sce`
--
ALTER TABLE `T_scenario_sce`
  ADD PRIMARY KEY (`sce_idscenario`),
  ADD KEY `fk_T_Scenarion_sce_T_compte_cpt1_idx` (`cpt_idcompte`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `T_actualite_act`
--
ALTER TABLE `T_actualite_act`
  MODIFY `act_idactualite` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT pour la table `T_compte_cpt`
--
ALTER TABLE `T_compte_cpt`
  MODIFY `cpt_idcompte` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT pour la table `T_etape_etp`
--
ALTER TABLE `T_etape_etp`
  MODIFY `etp_idetape` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT pour la table `T_Indice_ind`
--
ALTER TABLE `T_Indice_ind`
  MODIFY `ind_idindice` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT pour la table `T_ressources_rsc`
--
ALTER TABLE `T_ressources_rsc`
  MODIFY `rsc_idressources` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `T_scenario_participant_sp`
--
ALTER TABLE `T_scenario_participant_sp`
  MODIFY `sce_idscenario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `T_scenario_sce`
--
ALTER TABLE `T_scenario_sce`
  MODIFY `sce_idscenario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `T_actualite_act`
--
ALTER TABLE `T_actualite_act`
  ADD CONSTRAINT `fk_T_actualite_act_T_compte_cpt` FOREIGN KEY (`cpt_idcompte`) REFERENCES `T_compte_cpt` (`cpt_idcompte`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `T_etape_etp`
--
ALTER TABLE `T_etape_etp`
  ADD CONSTRAINT `fk_T_etape_etp_T_Scenarion_sce1` FOREIGN KEY (`sce_idscenario`) REFERENCES `T_scenario_sce` (`sce_idscenario`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_T_etape_etp_T_ressources_rsc1` FOREIGN KEY (`rsc_idressources`) REFERENCES `T_ressources_rsc` (`rsc_idressources`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `T_Indice_ind`
--
ALTER TABLE `T_Indice_ind`
  ADD CONSTRAINT `fk_T_Indice_ind_T_etape_etp1` FOREIGN KEY (`etp_idetape`) REFERENCES `T_etape_etp` (`etp_idetape`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `T_scenario_participant_sp`
--
ALTER TABLE `T_scenario_participant_sp`
  ADD CONSTRAINT `fk_T_Scenarion_sce_has_T_participant_par_T_Scenarion_sce1` FOREIGN KEY (`sce_idscenario`) REFERENCES `T_scenario_sce` (`sce_idscenario`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_T_Scenarion_sce_has_T_participant_par_T_participant_par1` FOREIGN KEY (`par_adresseparticipant`) REFERENCES `T_participant_par` (`par_adresseparticipant`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `T_scenario_sce`
--
ALTER TABLE `T_scenario_sce`
  ADD CONSTRAINT `T_scenario_sce_ibfk_1` FOREIGN KEY (`cpt_idcompte`) REFERENCES `T_compte_cpt` (`cpt_idcompte`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_T_Scenarion_sce_T_compte_cpt1` FOREIGN KEY (`cpt_idcompte`) REFERENCES `T_compte_cpt` (`cpt_idcompte`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
